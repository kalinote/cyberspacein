import asyncio
from html import escape
from typing import Union

from loguru import logger

from app.schemas.search import (
    EntityKeywordSearchParams,
    EntitySearchRequestSchema,
    EntitySearchToolHitSchema,
    SearchResultSchema,
)
from app.schemas.constants import ALL_INDEX, SearchModeEnum
from app.schemas.general import PageResponseSchema
from app.core.config import settings
from app.models.platform.platform import PlatformModel
from app.utils.date_time import parse_datetime
from app.utils.search import merge_highlight_tags, has_keywords, rrf_merge
from app.utils.embedding import embed_query_async

logger = logger.bind(name=__name__)

# 贴文先开放检索，详情及其他实体操作继续使用现有类型约束。
SEARCH_INDEXES = [*ALL_INDEX, "post"]


def _get_es_total(result: dict) -> int:
    total = result["hits"]["total"]
    return total["value"] if isinstance(total, dict) else total


SearchFilterParams = Union[EntitySearchRequestSchema, EntityKeywordSearchParams]


def build_filter_must(params: SearchFilterParams) -> list:
    must = []
    if params.platform:
        must.append({"term": {"platform.keyword": params.platform}})
    if params.entity_type:
        must.append({"terms": {"entity_type.keyword": params.entity_type}})
    if params.author:
        must.append({"term": {"author_name.keyword": params.author}})
    if params.aigc is not None:
        must.append({"term": {"aigc": params.aigc}})
    if params.nsfw is not None:
        must.append({"term": {"nsfw": params.nsfw}})
    if params.is_highlighted is not None:
        must.append({"term": {"is_highlighted": params.is_highlighted}})
    if params.start_at is not None or params.end_at is not None:
        range_clause = {}
        if params.start_at is not None:
            range_clause["gte"] = params.start_at.isoformat()
        if params.end_at is not None:
            range_clause["lte"] = params.end_at.isoformat()
        date_filter = {"range": {"last_edit_at": range_clause}}
        if not params.entity_type or "post" in params.entity_type:
            date_filter = {
                "bool": {
                    "should": [
                        date_filter,
                        {
                            "bool": {
                                "filter": [{"term": {"entity_type.keyword": "post"}}],
                                "must_not": [{"exists": {"field": "last_edit_at"}}],
                                "should": [
                                    {"range": {"publish_at": range_clause}},
                                    {
                                        "bool": {
                                            "must_not": [{"exists": {"field": "publish_at"}}],
                                            "filter": [{"range": {"crawled_at": range_clause}}],
                                        }
                                    },
                                ],
                                "minimum_should_match": 1,
                            }
                        },
                    ],
                    "minimum_should_match": 1,
                }
            }
        must.append(date_filter)
    return must


async def hit_to_search_result(hit: dict) -> SearchResultSchema:
    source_data = hit.get("_source", {})
    highlight_data = hit.get("highlight", {})
    platform_name = source_data.get("platform")
    platform_id = None
    if platform_name:
        try:
            platform = await PlatformModel.find_one({"name": platform_name})
            if platform:
                platform_id = platform.id
        except Exception as e:
            logger.warning(f"查询平台ID失败: {e}, platform_name: {platform_name}")
    title = highlight_data.get("title", [source_data.get("title", "")])[0]
    title = (merge_highlight_tags(title) or "") if title is not None else ""
    clean_content = source_data.get("clean_content")
    if highlight_data.get("clean_content"):
        clean_content = merge_highlight_tags(highlight_data["clean_content"][0])
    if source_data.get("entity_type") == "post" and not title:
        summary = " ".join(str(source_data.get("clean_content") or "").split())
        title = escape(summary[:80] + ("…" if len(summary) > 80 else "")) or "贴文"
    keywords_hits = 0
    if highlight_data:
        for fragments in highlight_data.values():
            for fragment in fragments:
                keywords_hits += fragment.count("<em>")
    return SearchResultSchema(
        uuid=source_data.get("uuid", hit.get("_id", "")),
        entity_type=source_data.get("entity_type", ""),
        source_id=source_data.get("source_id", ""),
        data_version=source_data.get("data_version", 0),
        platform=platform_name or "",
        platform_id=platform_id,
        section=source_data.get("section") or "",
        update_at=parse_datetime(source_data.get("update_at")),
        author_uuid=None,
        author_name=source_data.get("author_name") or "",
        nsfw=source_data.get("nsfw", False),
        aigc=source_data.get("aigc", False),
        keywords=source_data.get("keywords") or [],
        title=title,
        clean_content=clean_content,
        confidence=source_data.get("confidence", 1),
        is_highlighted=source_data.get("is_highlighted"),
        keywords_hits=keywords_hits
    )


async def hits_to_search_results(hits: list) -> list[SearchResultSchema]:
    return await asyncio.gather(*[hit_to_search_result(h) for h in hits])


def _normalize_keywords(keywords: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in keywords or []:
        kw = str(raw or "").strip()
        if not kw or kw in seen:
            continue
        seen.add(kw)
        out.append(kw)
    return out


def _single_keyword_should_clause(keyword: str) -> dict:
    return {
        "bool": {
            "should": [
                {"match": {"title": keyword}},
                {"match": {"clean_content": keyword}},
                {"match": {"raw_content": keyword}},
                {"term": {"keywords": keyword}},
                {"term": {"author_name": keyword}},
            ],
            "minimum_should_match": 1,
        }
    }


def build_keyword_must_clause(keywords: list[str], mode: str) -> dict | None:
    normalized = _normalize_keywords(keywords)
    if not normalized:
        return None
    clauses = [_single_keyword_should_clause(kw) for kw in normalized]
    if str(mode or "and").lower() == "or":
        return {"bool": {"should": clauses, "minimum_should_match": 1}}
    return {"bool": {"must": clauses}}


def hit_to_tool_search_hit(hit: dict) -> EntitySearchToolHitSchema:
    source_data = hit.get("_source", {})
    highlight_data = hit.get("highlight", {})
    title = str(source_data.get("title") or "")
    snippets: list[str] = []
    for fragment in highlight_data.get("clean_content") or []:
        merged = merge_highlight_tags(fragment)
        if merged:
            snippets.append(merged)
    keywords_hits = 0
    if highlight_data:
        for fragments in highlight_data.values():
            for fragment in fragments:
                keywords_hits += fragment.count("<em>")
    return EntitySearchToolHitSchema(
        uuid=source_data.get("uuid", hit.get("_id", "")),
        entity_type=source_data.get("entity_type", ""),
        title=title,
        snippets=snippets,
        keywords_hits=keywords_hits,
    )


def hits_to_tool_search_hits(hits: list) -> list[EntitySearchToolHitSchema]:
    return [hit_to_tool_search_hit(h) for h in hits]


def _apply_sort_to_body(body: dict, params: SearchFilterParams) -> None:
    if params.sort_by == "relevance":
        return
    sort_order = params.sort_order if params.sort_order in ["asc", "desc"] else "desc"
    if params.sort_by in ["last_edit_at", "time"]:
        body["sort"] = [
            {"last_edit_at": {"order": sort_order, "missing": "_last", "unmapped_type": "date"}},
            {"publish_at": {"order": sort_order, "missing": "_last", "unmapped_type": "date"}},
            {"crawled_at": {"order": sort_order, "missing": "_last", "unmapped_type": "date"}},
        ]
    elif params.sort_by == "publish_at":
        body["sort"] = [{"publish_at": {"order": sort_order, "missing": "_last", "unmapped_type": "date"}}]
    elif params.sort_by == "priority":
        body["sort"] = [
            {"confidence": {"order": "desc", "missing": "_last", "unmapped_type": "double"}},
            {"crawled_at": {"order": "desc", "missing": "_last", "unmapped_type": "date"}},
        ]
    elif params.sort_by == "crawled_at":
        body["sort"] = [{"crawled_at": {"order": sort_order, "missing": "_last", "unmapped_type": "date"}}]
    else:
        body["sort"] = [{"crawled_at": {"order": "desc", "missing": "_last", "unmapped_type": "date"}}]


def keyword_list_query_body(
    params: EntityKeywordSearchParams, from_: int, size: int
) -> dict:
    query_must: list = []
    keyword_clause = build_keyword_must_clause(
        params.keywords, params.keyword_match_mode
    )
    if keyword_clause is not None:
        query_must.append(keyword_clause)
    for c in build_filter_must(params):
        query_must.append(c)
    body: dict = {
        "query": {"bool": {"must": query_must if query_must else [{"match_all": {}}]}},
        "from": from_,
        "size": size,
    }
    if keyword_clause is not None:
        body["highlight"] = {
            "pre_tags": ["<em>"],
            "post_tags": ["</em>"],
            "fields": {
                "title": {},
                "clean_content": {"fragment_size": 200, "number_of_fragments": 3},
            },
        }
    _apply_sort_to_body(body, params)
    return body


async def search_filter_only_tool(
    es, params: EntityKeywordSearchParams
) -> PageResponseSchema[EntitySearchToolHitSchema]:
    filter_must = build_filter_must(params)
    query = {
        "bool": {
            "must": [{"match_all": {}}],
            "filter": filter_must if filter_must else [],
        }
    }
    from_ = (params.page - 1) * params.page_size
    query_body: dict = {
        "query": query,
        "from": from_,
        "size": params.page_size,
    }
    _apply_sort_to_body(query_body, params)
    result = await es.search(index=ALL_INDEX, body=query_body)
    total = _get_es_total(result)
    hits = result["hits"]["hits"]
    items = hits_to_tool_search_hits(hits)
    return PageResponseSchema.create(
        items=items, total=total, page=params.page, page_size=params.page_size
    )


async def search_entities_keyword(
    es, params: EntityKeywordSearchParams
) -> PageResponseSchema[EntitySearchToolHitSchema]:
    if not _normalize_keywords(params.keywords):
        return await search_filter_only_tool(es, params)
    from_ = (params.page - 1) * params.page_size
    query_body = keyword_list_query_body(params, from_, params.page_size)
    result = await es.search(index=ALL_INDEX, body=query_body)
    total = _get_es_total(result)
    hits = result["hits"]["hits"]
    items = hits_to_tool_search_hits(hits)
    return PageResponseSchema.create(
        items=items, total=total, page=params.page, page_size=params.page_size
    )


async def search_filter_only(es, params: EntitySearchRequestSchema) -> PageResponseSchema[SearchResultSchema]:
    filter_must = build_filter_must(params)
    query = {
        "bool": {
            "must": [{"match_all": {}}],
            "filter": filter_must if filter_must else []
        }
    }
    from_ = (params.page - 1) * params.page_size
    query_body = {
        "query": query,
        "from": from_,
        "size": params.page_size
    }
    
    if params.sort_by is not None:
        _apply_sort_to_body(query_body, params)

    result = await es.search(index=SEARCH_INDEXES, body=query_body, ignore_unavailable=True, allow_no_indices=True)
    total = _get_es_total(result)
    hits = result["hits"]["hits"]
    items = await hits_to_search_results(hits)
    return PageResponseSchema.create(items=items, total=total, page=params.page, page_size=params.page_size)


async def search_keyword(es, params: EntitySearchRequestSchema) -> PageResponseSchema[SearchResultSchema]:
    from_ = (params.page - 1) * params.page_size
    query_body = keyword_query_body(params, from_, params.page_size)
    result = await es.search(index=SEARCH_INDEXES, body=query_body, ignore_unavailable=True, allow_no_indices=True)
    total = _get_es_total(result)
    hits = result["hits"]["hits"]
    items = await hits_to_search_results(hits)
    return PageResponseSchema.create(items=items, total=total, page=params.page, page_size=params.page_size)


def keyword_query_body(params: EntitySearchRequestSchema, from_: int, size: int) -> dict:
    query_must = []
    if has_keywords(params.keywords):
        query_must.append({
            "bool": {
                "should": [
                    {"match": {"title": params.keywords}},
                    {"match": {"clean_content": params.keywords}},
                    {"match": {"raw_content": params.keywords}},
                    {"term": {"keywords": params.keywords}},
                    {"term": {"author_name": params.keywords}}
                ],
                "minimum_should_match": 1
            }
        })
    filter_must = build_filter_must(params)
    for c in filter_must:
        query_must.append(c)
    body = {
        "query": {"bool": {"must": query_must if query_must else [{"match_all": {}}]}},
        "from": from_,
        "size": size
    }
    if has_keywords(params.keywords):
        body["highlight"] = {
            "pre_tags": ["<em>"],
            "post_tags": ["</em>"],
            "fields": {"title": {}, "clean_content": {"fragment_size": 200, "number_of_fragments": 3}}
        }
    _apply_sort_to_body(body, params)
    return body


async def search_vector(es, params: EntitySearchRequestSchema, query_vector: list[float]) -> PageResponseSchema[SearchResultSchema]:
    filter_must = build_filter_must(params)
    from_ = (params.page - 1) * params.page_size
    size = params.page_size
    k = max(from_ + size, 10)
    num_candidates = min(
        settings.VECTOR_NUM_CANDIDATES_MAX,
        max(k * settings.VECTOR_NUM_CANDIDATES_MULTIPLIER, settings.VECTOR_NUM_CANDIDATES_MIN)
    )
    knn = {
        "field": "clean_content_vector",
        "query_vector": query_vector,
        "k": k,
        "num_candidates": num_candidates
    }
    if filter_must:
        knn["filter"] = {"bool": {"must": filter_must}}
    query_body = {
        "query": {"knn": knn},
        "from": from_,
        "size": size
    }
    result = await es.search(index=SEARCH_INDEXES, body=query_body, ignore_unavailable=True, allow_no_indices=True)
    total = _get_es_total(result)
    hits = result["hits"]["hits"]
    items = await hits_to_search_results(hits)
    return PageResponseSchema.create(items=items, total=total, page=params.page, page_size=params.page_size)


async def search_entity(es, params: EntitySearchRequestSchema, instruct: str = "") -> PageResponseSchema[SearchResultSchema]:
    if not has_keywords(params.keywords):
        return await search_filter_only(es, params)

    if params.search_mode == SearchModeEnum.KEYWORD:
        return await search_keyword(es, params)

    if params.search_mode == SearchModeEnum.VECTOR:
        query_vector = await embed_query_async(params.keywords, instruct)
        return await search_vector(es, params, query_vector)

    if params.search_mode == SearchModeEnum.HYBRID:
        query_vector = await embed_query_async(params.keywords, instruct)
        hybrid_size = min(settings.HYBRID_TOTAL_CAP, max((params.page * params.page_size) + 200, 500))
        keyword_body = keyword_query_body(params, 0, hybrid_size)
        filter_must = build_filter_must(params)
        vec_k = hybrid_size
        vec_num_candidates = min(
            settings.VECTOR_NUM_CANDIDATES_MAX,
            max(vec_k * settings.VECTOR_NUM_CANDIDATES_MULTIPLIER, settings.VECTOR_NUM_CANDIDATES_MIN)
        )
        knn = {
            "field": "clean_content_vector",
            "query_vector": query_vector,
            "k": vec_k,
            "num_candidates": vec_num_candidates
        }
        if filter_must:
            knn["filter"] = {"bool": {"must": filter_must}}
        vector_body = {"query": {"knn": knn}, "from": 0, "size": hybrid_size}

        kw_result, vec_result = await asyncio.gather(
            es.search(index=SEARCH_INDEXES, body=keyword_body, ignore_unavailable=True, allow_no_indices=True),
            es.search(index=SEARCH_INDEXES, body=vector_body, ignore_unavailable=True, allow_no_indices=True)
        )

        kw_total = _get_es_total(kw_result)
        vec_total = _get_es_total(vec_result)
        keyword_hits = kw_result["hits"]["hits"]
        vector_hits = vec_result["hits"]["hits"]
        merged = rrf_merge(keyword_hits, vector_hits, settings.RRF_K)
        from_ = (params.page - 1) * params.page_size
        page_hits = merged[from_: from_ + params.page_size]
        total_estimate = min(settings.HYBRID_TOTAL_CAP, kw_total + vec_total)
        items = await hits_to_search_results(page_hits)
        return PageResponseSchema.create(
            items=items,
            total=total_estimate,
            page=params.page,
            page_size=params.page_size
        )

    return await search_keyword(es, params)
