"""HITL 审批握手：会话状态、SSE、决策队列与持久化补丁。

业务工具或步骤只需调用 `HitlService.request_approval(agent_id, session_id, source, payload)`，
在 `outcome.approved` 非空时执行副作用。前端按 SSE `approval_required.data.source` 分支渲染
`data.payload`。

扩展新来源：
1. 在 `HitlSource` 增加常量（如 `tool:run_command`）；
2. （可选）在 `app/schemas/agent/hitl.py` 增加 Payload 模型；
3. 调用方组装 `payload` 并 `request_approval`；
4. 写操作工具建议 `exclusive = True`。
"""
from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from loguru import logger

from app.service.analyst.context import (
    get_current_auto_approve_hitl,
    get_current_run_id,
    get_current_run_lease_token,
    get_current_run_worker_id,
)
from app.service.analyst.approval_store import AnalystApprovalStore
from app.service.analyst.runtime_store import AnalystRuntimeStore
from app.models.agent.nanobot import NanobotSessionModel
from app.models.agent.sse_event import NanobotAgentSseEventModel
from app.schemas.agent.hitl import validate_source
from app.schemas.agent.nanobot_agent import AgentServiceError
from app.schemas.agent.runtime_state import NanobotRunStatusEnum
from app.schemas.constants import NanobotSessionStatusEnum
from app.utils import status_codes

logger = logger.bind(name=__name__)


@dataclass
class HitlOutcome:
    approved: list[dict[str, Any]]
    rejections: list[str]
    resolution: str
    approval_request_id: str
    raw: dict[str, Any]


def parse_approval_decisions(
    decisions: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[str]]:
    approved: list[dict[str, Any]] = []
    rejections: list[str] = []
    for item in decisions or []:
        action = str(item.get("action") or "").lower()
        if not action:
            action = "approve" if item.get("approved") else "reject"
        if action in {"approve", "approved", "yes"}:
            approved.append(item)
        else:
            rejections.append(str(item.get("reason") or ""))
    return approved, rejections


def approval_resolution_label(
    approved: list[dict[str, Any]], rejections: list[str]
) -> str:
    if rejections and approved:
        return "mixed"
    if rejections:
        return "rejected"
    if approved:
        return "approved"
    return "rejected"


class HitlService:
    _pending_resumes: dict[str, asyncio.Queue] = {}
    _resume_lock: asyncio.Lock = asyncio.Lock()

    @classmethod
    async def clear_session(cls, session_id: str) -> None:
        session_id = str(session_id or "").strip()
        if not session_id:
            return
        async with cls._resume_lock:
            cls._pending_resumes.pop(session_id, None)

    @classmethod
    async def clear_all_sessions(cls) -> None:
        async with cls._resume_lock:
            cls._pending_resumes.clear()

    @classmethod
    async def _get_or_create_resume_queue(cls, session_id: str) -> asyncio.Queue:
        async with cls._resume_lock:
            queue = cls._pending_resumes.get(session_id)
            if queue is None:
                queue = asyncio.Queue()
                cls._pending_resumes[session_id] = queue
            return queue

    @classmethod
    def _build_approval_event_data(
        cls,
        *,
        agent_id: str,
        session_id: str,
        approval_request_id: str,
        source: str,
        payload: dict[str, Any],
        resolution: str | None,
        reject_reasons: list[str] | None,
    ) -> dict[str, Any]:
        return {
            "agent_id": agent_id,
            "session_id": session_id,
            "approval_request_id": approval_request_id,
            "source": source,
            "resolution": resolution,
            "reject_reasons": reject_reasons,
            "payload": payload,
        }

    @classmethod
    async def submit_decisions(
        cls,
        agent_id: str,
        session_id: str,
        approval_request_id: str,
        decisions: list[dict],
        resolver_user_id: str | None = None,
    ) -> None:
        session_id = str(session_id or "").strip()
        if not session_id:
            raise AgentServiceError(
                status_codes.INVALID_ARGUMENT, "session_id 不能为空"
            )
        doc = await NanobotSessionModel.find_one({"_id": session_id})
        if doc is None or doc.agent_id != agent_id:
            raise AgentServiceError(
                status_codes.NOT_FOUND_AGENT,
                f"会话不存在或不属于该 Agent: session_id={session_id}",
            )
        pending = doc.pending_approval if isinstance(doc.pending_approval, dict) else {}
        if (
            doc.status != NanobotSessionStatusEnum.AWAITING_APPROVAL
            or pending.get("approval_request_id") != approval_request_id
        ):
            raise AgentServiceError(
                status_codes.CONFLICT_STATE,
                "审批请求已失效、已被处理或不属于当前待审批步骤",
            )

        if doc.active_run_id:
            approved, rejections = parse_approval_decisions(decisions)
            resolution = approval_resolution_label(approved, rejections)
            resolved = await AnalystApprovalStore.resolve(
                approval_request_id=approval_request_id,
                agent_id=agent_id,
                session_id=session_id,
                decisions=decisions,
                resolution=resolution,
                reject_reasons=rejections or None,
                resolver_user_id=resolver_user_id,
            )
            if resolved is None:
                raise AgentServiceError(
                    status_codes.CONFLICT_STATE,
                    "审批请求已被其他请求处理，请刷新会话状态",
                )
            return

        queue = await cls._get_or_create_resume_queue(session_id)
        await queue.put(
            {
                "approval_request_id": approval_request_id,
                "decisions": decisions,
                "submitted_at": datetime.now(),
            }
        )

    @classmethod
    async def _await_decisions(cls, session_id: str) -> dict:
        session_id = str(session_id or "").strip()
        if not session_id:
            raise RuntimeError("HITL 等待决策需要非空 session_id")
        queue = await cls._get_or_create_resume_queue(session_id)
        return await queue.get()

    @classmethod
    async def _await_persisted_decision(
        cls,
        *,
        run_id: str,
        approval_request_id: str,
        worker_id: str,
        lease_token: str,
    ) -> dict[str, Any]:
        """轮询持久化审批和 Run 租约，使任意 API 实例都能提交决策。"""
        while True:
            approval = await AnalystApprovalStore.get(approval_request_id)
            if approval is None:
                raise RuntimeError(f"审批请求不存在: {approval_request_id}")
            if approval.status.value != "pending":
                return {
                    "approval_request_id": approval_request_id,
                    "decisions": list(approval.decisions or []),
                    "submitted_at": approval.resolved_at,
                }

            run = await AnalystRuntimeStore.get(run_id)
            if (
                run is None
                or not run.active
                or run.worker_id != worker_id
                or run.lease_token != lease_token
            ):
                raise RuntimeError("审批等待期间 Run 已结束或 Worker 已失去租约")
            await asyncio.sleep(0.25)

    @classmethod
    async def patch_persisted_approval_required(
        cls,
        agent_id: str,
        session_id: str,
        approval_request_id: str,
        *,
        resolution: str,
        reject_reasons: list[str] | None,
    ) -> None:
        session_id = str(session_id or "").strip()
        if not session_id or not approval_request_id:
            return
        try:
            rows = (
                await NanobotAgentSseEventModel.find(
                    {
                        "agent_id": agent_id,
                        "session_id": session_id,
                        "event": "approval_required",
                        "data.approval_request_id": approval_request_id,
                    }
                )
                .sort("-seq")
                .limit(1)
                .to_list()
            )
        except Exception:
            logger.exception(
                "补丁 approval_required SSE 失败（查询）: agent_id={} session_id={} req={}",
                agent_id,
                session_id,
                approval_request_id,
            )
            return
        if not rows:
            logger.warning(
                "未找到可补丁的 approval_required 事件: agent_id={} session_id={} req={}",
                agent_id,
                session_id,
                approval_request_id,
            )
            return
        doc = rows[0]
        raw = doc.data
        data = dict(raw) if isinstance(raw, dict) else {}
        if data.get("resolution") is not None:
            return
        data["resolution"] = resolution
        data["reject_reasons"] = reject_reasons
        doc.data = data
        try:
            await doc.save()
        except Exception:
            logger.exception(
                "补丁 approval_required SSE 失败（保存）: agent_id={} session_id={} req={}",
                agent_id,
                session_id,
                approval_request_id,
            )

    @classmethod
    async def request_approval(
        cls,
        agent_id: str,
        session_id: str,
        source: str,
        payload: dict[str, Any],
    ) -> HitlOutcome:
        from app.service.analyst.service import AnalystService

        if get_current_auto_approve_hitl():
            return HitlOutcome(
                approved=[{"action": "approve", "auto": True}],
                rejections=[],
                resolution="approved",
                approval_request_id=str(uuid.uuid4()),
                raw={"auto_approve": True},
            )

        source = validate_source(source)
        session_id = str(session_id or "").strip()
        if not session_id:
            raise RuntimeError("HITL 需要非空 session_id")

        approval_request_id = str(uuid.uuid4())
        requested_at = datetime.now().isoformat()
        business_payload = dict(payload)

        pending_record = {
            "approval_request_id": approval_request_id,
            "source": source,
            "requested_at": requested_at,
            "payload": business_payload,
        }

        run_id = get_current_run_id()
        worker_id = get_current_run_worker_id()
        lease_token = get_current_run_lease_token()
        if run_id:
            if not worker_id or not lease_token:
                raise RuntimeError("持久化 Run 缺少 Worker 租约上下文")
            await AnalystApprovalStore.create(
                approval_request_id=approval_request_id,
                run_id=run_id,
                session_id=session_id,
                agent_id=agent_id,
                source=source,
                payload=business_payload,
            )
            updated = await AnalystRuntimeStore.set_status(
                run_id,
                worker_id,
                lease_token,
                NanobotRunStatusEnum.AWAITING_APPROVAL,
            )
            if not updated:
                raise RuntimeError("进入待审批状态前已失去 Run 租约")

        session = await NanobotSessionModel.find_one({"_id": session_id})
        if session is None:
            raise RuntimeError(f"当前会话不存在: {session_id}")
        if run_id and lease_token:
            update = await NanobotSessionModel.get_motor_collection().update_one(
                {
                    "_id": session_id,
                    "active_run_id": run_id,
                    "active_run_lease_token": lease_token,
                },
                {
                    "$set": {
                        "status": NanobotSessionStatusEnum.AWAITING_APPROVAL.value,
                        "pending_approval": pending_record,
                        "updated_at": datetime.now(),
                    }
                },
            )
            if update.matched_count != 1:
                raise RuntimeError("写入待审批会话状态时 Run 已失效")
        else:
            session.status = NanobotSessionStatusEnum.AWAITING_APPROVAL
            session.pending_approval = pending_record
            session.updated_at = datetime.now()
            await session.save()

        event_pending = cls._build_approval_event_data(
            agent_id=agent_id,
            session_id=session_id,
            approval_request_id=approval_request_id,
            source=source,
            payload=business_payload,
            resolution=None,
            reject_reasons=None,
        )
        await AnalystService.broadcast_sse(
            agent_id, "approval_required", event_pending
        )
        await AnalystService.broadcast_sse(
            agent_id,
            "status",
            {
                "agent_id": agent_id,
                "session_id": session_id,
                "status": NanobotSessionStatusEnum.AWAITING_APPROVAL.value,
            },
        )

        try:
            if run_id and worker_id and lease_token:
                decision_msg = await cls._await_persisted_decision(
                    run_id=run_id,
                    approval_request_id=approval_request_id,
                    worker_id=worker_id,
                    lease_token=lease_token,
                )
            else:
                decision_msg = await cls._await_decisions(session_id)
        except Exception:
            logger.exception(
                f"HITL 等待审批异常: agent_id={agent_id} session_id={session_id} source={source}"
            )
            raise

        decisions = decision_msg.get("decisions") or []
        approved, rejections = parse_approval_decisions(decisions)
        resolution = approval_resolution_label(approved, rejections)

        session = await NanobotSessionModel.find_one({"_id": session_id})
        if session is not None:
            if run_id and lease_token:
                update = await NanobotSessionModel.get_motor_collection().update_one(
                    {
                        "_id": session_id,
                        "active_run_id": run_id,
                        "active_run_lease_token": lease_token,
                    },
                    {
                        "$set": {
                            "status": NanobotSessionStatusEnum.RUNNING.value,
                            "pending_approval": None,
                            "updated_at": datetime.now(),
                        }
                    },
                )
                if update.matched_count != 1:
                    raise RuntimeError("恢复运行状态时 Run 已失效")
            else:
                session.status = NanobotSessionStatusEnum.RUNNING
                session.pending_approval = None
                session.updated_at = datetime.now()
                await session.save()

        if run_id and worker_id and lease_token:
            updated = await AnalystRuntimeStore.set_status(
                run_id,
                worker_id,
                lease_token,
                NanobotRunStatusEnum.RUNNING,
            )
            if not updated:
                raise RuntimeError("审批完成后恢复运行态时已失去 Run 租约")

        await cls.patch_persisted_approval_required(
            agent_id,
            session_id,
            approval_request_id,
            resolution=resolution,
            reject_reasons=rejections or None,
        )
        event_resolved = cls._build_approval_event_data(
            agent_id=agent_id,
            session_id=session_id,
            approval_request_id=approval_request_id,
            source=source,
            payload=business_payload,
            resolution=resolution,
            reject_reasons=rejections or None,
        )
        await AnalystService.broadcast_sse(
            agent_id,
            "approval_required",
            event_resolved,
            persist=False,
        )
        await AnalystService.broadcast_sse(
            agent_id,
            "status",
            {
                "agent_id": agent_id,
                "session_id": session_id,
                "status": NanobotSessionStatusEnum.RUNNING.value,
            },
        )

        return HitlOutcome(
            approved=approved,
            rejections=rejections,
            resolution=resolution,
            approval_request_id=approval_request_id,
            raw=decision_msg,
        )
