from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field
from app.schemas.action.blueprint import GraphSchema
from app.schemas.constants import (
    ActionConfigIOTypeEnum,
    ActionFlowStatusEnum,
    ActionInstanceNodeStatusEnum,
    ActionNodeDefinitionOriginEnum,
    ActionNodeKindEnum,
)

class StartActionRequest(BaseModel):
    blueprint_id: str = Field(description="蓝图ID")
    params: dict[str, Any] | None = Field(default=None, description="行动参数")
    debug: bool = Field(default=False, description="是否以调试模式运行")
    
class StartActionResponse(BaseModel):
    action_id: str = Field(description="行动ID")


class ActionControlResponse(BaseModel):
    action_id: str = Field(description="行动ID")
    status: ActionFlowStatusEnum = Field(description="行动当前状态")
    
class ActionInstanceBaseInfoResponse(BaseModel):
    id: str = Field(description="行动ID")
    name: str = Field(description="行动名称")
    description: str = Field(description="行动描述")
    status: ActionFlowStatusEnum = Field(description="行动实例化流程状态")
    debug: bool = Field(default=False, description="是否为调试运行")
    start_at: datetime | None = Field(default=None, description="行动实例化流程开始时间")
    paused_at: datetime | None = Field(default=None, description="行动最近一次暂停时间")
    finished_at: datetime | None = Field(default=None, description="行动实例化流程结束时间")
    duration: float = Field(description="行动执行时长(秒)")
    progress: int = Field(description="行动实例化流程进度(%)")
    completed_steps: int = Field(description="已完成的节点数量")
    total_steps: int = Field(description="总节点数量")
    schedule_id: str | None = None
    schedule_name: str | None = None
    schedule_priority: int = 5
    scheduled_for: datetime | None = None
    created_at: datetime | None = None
    

class ActionNodeDetailResponse(BaseModel):
    node_instance_id: str | None = Field(default=None, description="节点实例ID")
    status: ActionInstanceNodeStatusEnum = Field(description="节点状态")
    progress: int = Field(default=0, description="节点执行进度(%)")
    start_at: datetime | None = Field(default=None, description="节点执行开始时间")
    finished_at: datetime | None = Field(default=None, description="节点执行结束时间")
    duration: float = Field(default=0, description="节点执行时长(秒)")
    inputs: dict[str, Any] = Field(default_factory=dict, description="节点输入配置")
    outputs: dict[str, Any] = Field(default_factory=dict, description="节点输出配置")
    error_message: str | None = Field(default=None, description="节点执行错误信息")
    component_runs: list[dict[str, Any]] = Field(default_factory=list)
    log_count: int = 0
    error_log_count: int = 0
    dropped_log_count: int = 0
    driver: str | None = None
    handler: str | None = None
    node_kind: ActionNodeKindEnum | None = None
    definition_origin: ActionNodeDefinitionOriginEnum | None = None
    definition: dict[str, Any] | None = None
    current_execution_id: str | None = None
    execution_ids: list[str] = Field(default_factory=list)
    provider_run_id: str | None = None
    extension_state: dict[str, Any] = Field(default_factory=dict)
    extension_result: dict[str, Any] = Field(default_factory=dict)
    skip_reason: str | None = None
    embedded_action_id: str | None = None
    source_blueprint_id: str | None = None
    source_revision_id: str | None = None
    child_status: str | None = None
    child_progress: float | None = None

class ActionDetailResponse(ActionInstanceBaseInfoResponse):
    """
    行动详细信息的响应，用于正在执行的行动详细的信息页
    """
    graph: GraphSchema = Field(description="行动蓝图，用于标识基本结构和布局")
    resource: dict[str, Any] = Field(
        default_factory=dict,
        description="分配资源，暂未实现",
    )
    implementation_period: int = Field(default=0, ge=0, description="执行期限(秒)，0表示不限制")
    node_details: dict[str, ActionNodeDetailResponse] = Field(description="节点详细信息")

class ActionConfigMeta(BaseModel):
    node_instance_id: str = Field(description="节点实例ID")
    action_id: str = Field(description="行动ID")

class ActionConfigIO(BaseModel):
    type: ActionConfigIOTypeEnum = Field(description="数据类型")
    value: Any | None = Field(default=None, description="数据值")

class ActionNodeConfigInitResponse(BaseModel):
    """
    节点配置初始化响应，用于基础构建SDK获取基本节点参数配置
    """
    meta: ActionConfigMeta = Field(description="节点配置元数据")
    config: dict[str, Any] = Field(default_factory=dict, description="节点配置")
    inputs: dict[str, ActionConfigIO] = Field(
        default_factory=dict,
        description="节点输入配置",
    )
    outputs: dict[str, ActionConfigIO] = Field(
        default_factory=dict,
        description="节点输出配置",
    )
