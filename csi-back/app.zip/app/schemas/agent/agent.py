from datetime import datetime
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from app.models.agent.configs import AgentModelConfigModel, AgentPromptTemplateModel


class AgentModelConfigCreateRequestSchema(BaseModel):
    name: str = Field(description="模型名称", min_length=1)
    description: str | None = Field(default=None, description="模型描述")
    base_url: str = Field(description="模型基础URL", min_length=1)
    api_key: str = Field(description="模型API密钥")
    model: str = Field(description="模型ID", min_length=1)


class AgentModelConfigUpdateRequestSchema(BaseModel):
    name: str = Field(description="模型名称", min_length=1)
    description: str | None = Field(default=None, description="模型描述")
    base_url: str = Field(description="模型基础URL", min_length=1)
    api_key: str | None = Field(default=None, description="留空表示不修改")
    model: str = Field(description="模型ID", min_length=1)


class AgentModelConfigSchema(BaseModel):
    id: str = Field(description="配置ID")
    name: str = Field(description="模型名称")
    description: str | None = Field(default=None, description="模型描述")
    base_url: str = Field(description="模型基础URL")
    api_key: str | None = Field(default=None, description="模型API密钥；无敏感读取权限时为空")
    model: str = Field(description="模型ID")
    created_at: datetime = Field(description="创建时间")
    updated_at: datetime = Field(description="更新时间")

    @classmethod
    def from_doc(cls, doc: "AgentModelConfigModel", include_secret: bool = False) -> "AgentModelConfigSchema":
        return cls(
            id=doc.id,
            name=doc.name,
            description=doc.description,
            base_url=doc.base_url,
            api_key=doc.api_key if include_secret else None,
            model=doc.model,
            created_at=doc.created_at,
            updated_at=doc.updated_at,
        )


class AgentModelConfigListItemSchema(BaseModel):
    id: str
    name: str
    description: str | None = None
    base_url: str
    model: str
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_doc(cls, doc: "AgentModelConfigModel") -> "AgentModelConfigListItemSchema":
        return cls(
            id=doc.id,
            name=doc.name,
            description=doc.description,
            base_url=doc.base_url,
            model=doc.model,
            created_at=doc.created_at,
            updated_at=doc.updated_at,
        )


class AgentPromptTemplateCreateRequestSchema(BaseModel):
    name: str = Field(description="提示词模板名称", min_length=1)
    description: str = Field(description="提示词模板描述")
    system_prompt: str = Field(description="系统提示词")
    user_prompt: str = Field(description="第一段用户提示词模板")


class AgentPromptTemplateSchema(BaseModel):
    id: str = Field(description="模板ID")
    name: str = Field(description="提示词模板名称")
    description: str = Field(description="提示词模板描述")
    system_prompt: str = Field(description="系统提示词")
    user_prompt: str = Field(description="第一段用户提示词模板")
    created_at: datetime = Field(description="创建时间")
    updated_at: datetime = Field(description="更新时间")

    @classmethod
    def from_doc(cls, doc: "AgentPromptTemplateModel") -> "AgentPromptTemplateSchema":
        return cls(
            id=doc.id,
            name=doc.name,
            description=doc.description,
            system_prompt=doc.system_prompt,
            user_prompt=doc.user_prompt,
            created_at=doc.created_at,
            updated_at=doc.updated_at,
        )


class AgentCreateRequestSchema(BaseModel):
    name: str = Field(description="Agent名称", min_length=1)
    description: str = Field(description="Agent描述")
    prompt_template_id: str = Field(description="提示词模板id")
    model_id: str = Field(description="模型配置id")
    llm_config: dict[str, Any] = Field(description="LLM配置，包括模型、温度等")
    tools: list[str] = Field(default_factory=list, description="工具列表")


class AgentRuntimeRequestSchema(BaseModel):
    """`/agent/start` 与 `/agent/message` 共用请求体。"""

    agent_id: str = Field(description="分析引擎ID")
    session_id: str | None = Field(
        default=None,
        description="会话 ID；续聊 `/agent/message` 必填，`/agent/start` 不传",
    )
    user_prompt: str | None = Field(
        default=None,
        description="用户本轮 prompt；`/agent/message` 必填，`/agent/start` 可空则回退模板",
    )
    injection_param: dict[str, Any] = Field(
        default_factory=dict,
        description="Jinja 渲染与业务透传参数（如 entity_uuid、entity_type 等）",
    )
    auto_approve: bool = Field(
        default=False,
        description="为 true 时，本轮 run 内工具触发的 HITL 自动批准，不等待 /agent/approve",
    )
    merge_user_prompts: bool = Field(
        default=False,
        description=(
            "仅 `/agent/start` 有效；为 true 时合并提示词模板 user_prompt（前）与请求 user_prompt（后），"
            "两段之间空一行，且请求 user_prompt 必填"
        ),
    )


class StartAgentResponseSchema(BaseModel):
    agent_id: str = Field(description="分析引擎ID")
    session_id: str = Field(description="本次启动分配的会话ID")


class SendAgentMessageResponseSchema(BaseModel):
    agent_id: str = Field(description="分析引擎ID")
    session_id: str = Field(description="续聊使用的会话ID")


class ApproveRequestSchema(BaseModel):
    agent_id: str = Field(description="分析引擎ID")
    session_id: str = Field(description="会话ID", min_length=1)
    approval_request_id: str = Field(description="待决议审批请求 ID", min_length=1)
    decisions: list[dict] = Field(
        description="审批决策列表，必须与 approval_request_id 对应"
    )


class CancelAgentRequestSchema(BaseModel):
    agent_id: str = Field(description="分析引擎ID")
    session_id: str = Field(description="会话ID", min_length=1)
    reason: str = Field(default="user cancel", description="取消原因，用于审计与 SSE 日志")


class CancelAgentResponseSchema(BaseModel):
    agent_id: str = Field(description="分析引擎ID")
    cancelled: bool = Field(description="是否已持久化取消请求（活动 Run 不存在则为 False）")


class ToolDescriptorSchema(BaseModel):
    name: str = Field(description="工具名")
    description: str = Field(description="工具描述")
    read_only: bool = Field(description="是否只读")
    exclusive: bool = Field(description="是否需要独占执行（如涉及审批）")
