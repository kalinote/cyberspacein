from copy import deepcopy
from typing import Any
from datetime import datetime
from beanie import Document
from pydantic import BaseModel, Field
from app.schemas.action.interface import BlueprintInterfaceSpec, BoundaryBinding
from app.schemas.general import DictModelSchema
from app.schemas.constants import ActionSchedulingModeEnum


class PositionModel(BaseModel):
    """
    位置坐标模型
    """
    x: float
    y: float


class NodeDataModel(BaseModel):
    """
    节点数据模型
    """
    definition_id: str
    version: str
    form_data: list[DictModelSchema]
    node_definition_version: int = 1
    instance_config: dict[str, Any] = Field(default_factory=dict)
    interface_port_id: str | None = None
    boundary_binding: BoundaryBinding | None = None


class GraphNodeModel(BaseModel):
    """
    图节点模型
    """
    id: str
    type: str
    position: PositionModel
    data: NodeDataModel


class GraphEdgeModel(BaseModel):
    """
    图边模型
    """
    id: str
    source: str
    sourceHandle: str
    target: str
    targetHandle: str
    source_port_id: str | None = None
    target_port_id: str | None = None


class ViewportModel(BaseModel):
    """
    视口模型
    """
    x: float
    y: float
    zoom: float


class GraphModel(BaseModel):
    """
    图结构模型
    """
    nodes: list[GraphNodeModel]
    edges: list[GraphEdgeModel]
    viewport: ViewportModel


class ActionBlueprintSnapshotModel(BaseModel):
    """行动实例使用的完整蓝图快照。"""

    blueprint_id: str
    name: str
    version: str
    description: str
    target: str
    implementation_period: int = 0
    default_scheduling_mode: ActionSchedulingModeEnum = (
        ActionSchedulingModeEnum.BARRIER
    )
    resource: dict[str, Any] | None = None
    graph: GraphModel
    is_template: bool = False
    template: dict[str, Any] | None = None
    interface: BlueprintInterfaceSpec = Field(default_factory=BlueprintInterfaceSpec)


class ActionBlueprintModel(Document):
    """
    行动蓝图模型
    """
    id: str = Field(alias="_id")
    name: str
    version: str
    description: str
    target: str
    implementation_period: int = 0
    default_scheduling_mode: ActionSchedulingModeEnum = Field(
        default=ActionSchedulingModeEnum.BARRIER,
        description="蓝图默认调度模式",
    )
    resource: dict[str, Any] | None = None
    graph: GraphModel
    is_deleted: bool = Field(default=False, description="是否已删除")
    is_pinned: bool = Field(default=False, description="是否全局置顶到行动主页")
    is_template: bool = Field(default=False, description="是否为模板")
    # TODO: 后续增加对应的模型
    template: dict[str, Any] | None = Field(default=None, description="模板配置")
    interface: BlueprintInterfaceSpec = Field(
        default_factory=BlueprintInterfaceSpec,
        description="根据边界节点生成的公开接口",
    )
    
    created_at: datetime = Field(default_factory=lambda: datetime.now())
    updated_at: datetime = Field(default_factory=lambda: datetime.now())
    
    class Settings:
        name = "action_blueprints"
        indexes = [
            "id",
            "name",
        ]


def create_blueprint_snapshot(
    blueprint: ActionBlueprintModel,
) -> ActionBlueprintSnapshotModel:
    """复制蓝图为独立的行动实例快照。"""
    return ActionBlueprintSnapshotModel(
        blueprint_id=blueprint.id,
        name=blueprint.name,
        version=blueprint.version,
        description=blueprint.description,
        target=blueprint.target,
        implementation_period=blueprint.implementation_period,
        default_scheduling_mode=getattr(
            blueprint,
            "default_scheduling_mode",
            ActionSchedulingModeEnum.BARRIER,
        ),
        resource=deepcopy(blueprint.resource),
        graph=blueprint.graph.model_copy(deep=True),
        is_template=blueprint.is_template,
        template=deepcopy(blueprint.template),
        interface=getattr(
            blueprint,
            "interface",
            BlueprintInterfaceSpec(),
        ).model_copy(deep=True),
    )

