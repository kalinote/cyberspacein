import asyncio
from contextlib import asynccontextmanager, suppress
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from loguru import logger

from app.core.config import settings
from app.core.logging_config import setup_logging

setup_logging()

from app.core.exceptions import ApiException
from app.schemas.response import ApiResponseSchema
from app.middleware.response import ResponseMiddleware
import app.utils.status_codes as status_codes
from app.db import (
    init_mariadb, close_mariadb,
    init_mongodb, close_mongodb,
    init_redis, close_redis,
    init_elasticsearch, close_elasticsearch,
    init_rabbitmq, close_rabbitmq
)
from app.utils.cos import init_cos, close_cos
from app.utils.embedding import init_embedding_client, close_embedding_client
from app.service.auth.service import ensure_default_admin
from app.core.system_config import system_config_manager

logger = logger.bind(name=__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.validate_auth_security()
    settings.validate_analyst_runtime()
    await init_mariadb()
    await init_mongodb()
    from app.service.alert_source_bootstrap import register_builtin_alert_sources
    register_builtin_alert_sources()
    from app.service.native_nodes import sync_builtin_native_nodes
    await sync_builtin_native_nodes()
    await init_redis()
    await init_elasticsearch()
    from app.service.action.log import ActionLogService
    await ActionLogService.ensure_storage()
    await init_rabbitmq()
    await init_cos()
    await init_embedding_client()
    from app.core.permissions import sync_standard_permissions
    await sync_standard_permissions()
    await ensure_default_admin()
    from app.service.nanobot.bootstrap import ensure_builtin_agent_prompts
    await ensure_builtin_agent_prompts()

    analyst_runtime_worker = None
    if settings.NANOBOT_RUNTIME_WORKER_ENABLED:
        from app.service.analyst.runtime_worker import AnalystRuntimeWorker

        analyst_runtime_worker = AnalystRuntimeWorker()
        await analyst_runtime_worker.start()

    from app.service.entity_content_analysis_runtime import (
        EntityContentAnalysisRuntimeWorker,
    )

    entity_content_analysis_worker = EntityContentAnalysisRuntimeWorker()
    await entity_content_analysis_worker.start()

    from app.service.debug_output_runtime import DebugOutputRuntimeWorker

    debug_output_worker = DebugOutputRuntimeWorker()
    await debug_output_worker.start()

    async def monitor_action_timeouts() -> None:
        """周期收敛行动整体超时和组件运行超时。"""
        from app.service.action import ActionInstanceService

        while True:
            try:
                await ActionInstanceService.expire_stale_actions()
                await ActionInstanceService.expire_stale_component_runs()
                await ActionInstanceService.reconcile_node_executions()
                await ActionInstanceService.retry_open_reference_aborts()
                await ActionInstanceService.retry_failed_queue_cleanup()
            except Exception as exc:
                logger.error(f"行动运行超时检查失败: {exc}")
            await asyncio.sleep(settings.ACTION_TIMEOUT_CHECK_INTERVAL_SECONDS)

    async def monitor_action_runtime_events() -> None:
        """独立消费子行动终态事件，避免被全量超时对账阻塞。"""
        from app.service.action import ActionInstanceService

        while True:
            try:
                await ActionInstanceService.consume_runtime_events()
            except Exception as exc:
                logger.error(f"行动运行事件消费失败: {exc}")
            await asyncio.sleep(
                min(settings.ACTION_TIMEOUT_CHECK_INTERVAL_SECONDS, 1.0)
            )

    async def monitor_reference_bridges() -> None:
        """并发推进可恢复的 Reference 父子队列桥接。"""
        from app.service.action import ActionInstanceService
        from app.service.reference_bridge import ReferenceBridgeService

        worker_id = f"reference-bridge:{uuid4()}"
        tasks: set[asyncio.Task] = set()
        try:
            while True:
                try:
                    for task in tuple(tasks):
                        if not task.done():
                            continue
                        tasks.remove(task)
                        try:
                            task.result()
                        except asyncio.CancelledError:
                            pass
                        except Exception as exc:
                            logger.error(f"Reference桥接执行失败: {exc}")

                    while len(tasks) < 16:
                        bridge = await ReferenceBridgeService.claim(
                            worker_id=worker_id
                        )
                        if bridge is None:
                            break
                        tasks.add(
                            asyncio.create_task(
                                ReferenceBridgeService.run_claimed(
                                    bridge_id=bridge.id,
                                    worker_id=worker_id,
                                    lease_token=bridge.lease_token,
                                )
                            )
                        )

                    await ActionInstanceService.finalize_reference_actions()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    logger.error(f"Reference桥接巡检失败: {exc}")
                await asyncio.sleep(0.1)
        finally:
            for task in tasks:
                task.cancel()
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)

    action_timeout_task = asyncio.create_task(monitor_action_timeouts())
    action_runtime_event_task = asyncio.create_task(
        monitor_action_runtime_events()
    )
    reference_bridge_task = asyncio.create_task(monitor_reference_bridges())

    system_config_manager.commit_bootstrap()
    from app.service.system_config_history import SystemConfigHistoryService
    await SystemConfigHistoryService.flush_outbox(system_config_manager)
    await SystemConfigHistoryService.ensure_baseline(system_config_manager)

    yield

    action_timeout_task.cancel()
    action_runtime_event_task.cancel()
    reference_bridge_task.cancel()
    with suppress(asyncio.CancelledError):
        await action_timeout_task
    with suppress(asyncio.CancelledError):
        await action_runtime_event_task
    with suppress(asyncio.CancelledError):
        await reference_bridge_task

    system_config_manager.mark_not_ready()

    await debug_output_worker.stop()
    await entity_content_analysis_worker.stop()

    if analyst_runtime_worker is not None:
        await analyst_runtime_worker.stop()

    from app.service.analyst.service import AnalystService
    await AnalystService.shutdown_running_agents()

    await close_embedding_client()
    await close_cos()
    await close_rabbitmq()
    await close_mariadb()
    await close_mongodb()
    await close_redis()
    await close_elasticsearch()


app = FastAPI(
    title=settings.APP_NAME,
    openapi_url="/openapi.json",
    swagger_ui_parameters={"persistAuthorization": True},
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(ResponseMiddleware)


@app.get("/health/live", include_in_schema=False)
async def health_live():
    return {"status": "live", "boot_id": system_config_manager.boot_id}


@app.get("/health/ready", include_in_schema=False)
async def health_ready():
    if not system_config_manager.ready:
        return JSONResponse(status_code=503, content={"status": "not_ready"})
    return {
        "status": "ready",
        "boot_id": system_config_manager.boot_id,
        "version": system_config_manager.state()["version"],
    }


@app.exception_handler(ApiException)
async def api_exception_handler(request: Request, exc: ApiException):
    return JSONResponse(
        status_code=200,
        content=ApiResponseSchema.error(
            code=exc.code,
            message=exc.message,
            data=exc.data
        ).model_dump()
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = []
    for error in exc.errors():
        field = " -> ".join(str(loc) for loc in error["loc"])
        errors.append(f"{field}: {error['msg']}")
    
    return JSONResponse(
        status_code=200,
        content=ApiResponseSchema.error(
            code=status_codes.VALIDATION_ERROR,
            message="请求参数验证失败",
            data={"errors": errors}
        ).model_dump()
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    try:
        normalized_code = status_codes.build_status_code(
            status_codes.StatusCodeSource.HTTP_STANDARD,
            exc.status_code,
        )
    except ValueError:
        normalized_code = status_codes.INTERNAL_ERROR
    return JSONResponse(
        status_code=200,
        content=ApiResponseSchema.error(
            code=normalized_code,
            message=str(exc.detail) if exc.detail else "请求处理失败",
            data=None
        ).model_dump()
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.exception("未处理的异常")
    return JSONResponse(
        status_code=200,
        content=ApiResponseSchema.error(
            code=status_codes.INTERNAL_ERROR,
            message="服务器内部错误",
            data=None
        ).model_dump()
    )


from app.api.v1 import api as api_v1
app.include_router(api_v1.api_router, prefix=settings.API_V1_STR)

from app.core.route_permissions import validate_fastapi_routes
validate_fastapi_routes(app.routes)
