import asyncio
import json
from typing import Any

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse, StreamingResponse
from loguru import logger

from app.models.agent.configs import AgentPromptTemplateModel  # noqa: F401
from app.models.agent.nanobot import NanobotAgentModel  # noqa: F401
from app.schemas.agent.agent import (
    AgentRuntimeRequestSchema,
    ApproveRequestSchema,
    CancelAgentRequestSchema,
    CancelAgentResponseSchema,
    SendAgentMessageResponseSchema,
    StartAgentResponseSchema,
)
from app.schemas.agent.nanobot_agent import AgentServiceError
from app.schemas.response import ApiResponseSchema
from app.service.analyst.service import AnalystService
from app.service.analysis_invocation import (
    AnalysisInvocationRequest,
    AnalysisInvocationService,
)
from app.utils.jinja_injection import render_user_prompt
import app.utils.status_codes as status_codes

logger = logger.bind(name=__name__)

router = APIRouter()


@router.post(
    "/start",
    response_model=ApiResponseSchema[StartAgentResponseSchema],
    summary="启动分析引擎",
    description=(
        "成功时返回 `data.session_id`。后续 SSE `/agent/status` 会收到 `user_message`（首轮用户输入）与 `status` 等事件；"
        "取消与审批接口均须携带同一 `session_id`。"
        "请求体 `auto_approve=true` 时，本轮 run 内写操作工具自动批准，无需调用 `/agent/approve`（仅本轮有效）。"
        "请求体 `merge_user_prompts=true` 时，将提示词模板 user_prompt（前）与请求 user_prompt（后）分别 Jinja 渲染后合并，"
        "两段之间空一行，且请求 `user_prompt` 必填。"
        "当环境变量 `NANOBOT_AGENT_MAX_PARALLEL_SESSIONS` 大于 0 且该 Agent 的持久化活动 Run 已占满原子槽位时，"
        "返回 HTTP 200 且业务码为冲突态（`CONFLICT_STATE`），不会在库中新建本会话。"
    ),
)
async def start_agent(data: AgentRuntimeRequestSchema, request: Request):
    try:
        ref = await AnalysisInvocationService.submit(
            AnalysisInvocationRequest(
                agent_id=data.agent_id,
                user_prompt=data.user_prompt,
                injection_param=dict(data.injection_param),
                merge_user_prompts=data.merge_user_prompts,
                auto_approve=data.auto_approve,
                initiator_user_id=getattr(
                    getattr(
                        getattr(request.state, "auth_context", None),
                        "user",
                        None,
                    ),
                    "id",
                    None,
                ),
            )
        )
    except AgentServiceError as exc:
        return ApiResponseSchema.error(code=exc.code, message=exc.message, data=exc.data)
    return ApiResponseSchema.success(
        data=StartAgentResponseSchema(
            agent_id=data.agent_id,
            session_id=ref.session_id,
        )
    )


@router.post(
    "/message",
    response_model=ApiResponseSchema[SendAgentMessageResponseSchema],
    summary="向已结束会话提交续聊消息",
    description=(
        "仅当会话状态为 `completed`、`failed` 或 `cancelled` 时可提交；"
        "`running`、`awaiting_approval`、`paused` 等状态返回冲突错误。"
        "成功后会话重新进入 `running`，并通过 SSE 推送 `user_message`（用户本轮输入）与 `status`；"
        "后续仍通过 `/agent/status` 订阅其它事件。"
        "请求体 `auto_approve=true` 时，本轮 run 内写操作工具自动批准，无需调用 `/agent/approve`（仅本轮有效）。"
    ),
)
async def send_agent_message(data: AgentRuntimeRequestSchema, request: Request):
    try:
        session_id = str(data.session_id or "").strip()
        if not session_id:
            raise AgentServiceError(
                status_codes.INVALID_ARGUMENT, "session_id 不能为空"
            )

        raw_user_prompt = str(data.user_prompt or "").strip()
        if not raw_user_prompt:
            raise AgentServiceError(
                status_codes.INVALID_ARGUMENT, "user_prompt 不能为空"
            )

        injection_param = dict(data.injection_param)
        final_user_prompt = render_user_prompt(
            raw_user_prompt, injection_param
        ).strip()
        if not final_user_prompt:
            raise AgentServiceError(
                status_codes.INVALID_ARGUMENT,
                "用户提示词为空，且模板渲染后仍为空",
            )

        session_id = await AnalystService.send_message(
            agent_id=data.agent_id,
            session_id=session_id,
            user_prompt=final_user_prompt,
            context=injection_param,
            auto_approve=data.auto_approve,
            initiator_user_id=getattr(
                getattr(getattr(request.state, "auth_context", None), "user", None),
                "id",
                None,
            ),
        )
    except AgentServiceError as exc:
        return ApiResponseSchema.error(code=exc.code, message=exc.message, data=exc.data)
    return ApiResponseSchema.success(
        data=SendAgentMessageResponseSchema(
            agent_id=data.agent_id, session_id=session_id
        )
    )

@router.get(
    "/status",
    summary="订阅指定会话的状态事件流（SSE）",
    description=(
        "默认全量回放历史事件后持续推送实时事件。"
        "可选 `limit`/`offset` 仅影响历史回放：`limit` 限制回放条数（从最新起算），"
        "`offset` 从最新事件起跳过条数；实时新事件不受分页参数影响。"
    ),
)
async def get_agent_status(
    request: Request,
    agent_id: str = Query(..., description="分析引擎ID"),
    session_id: str = Query(..., description="会话ID"),
    limit: int | None = Query(
        None, ge=1, description="回放条数上限；仅影响历史回放，不传则全量"
    ),
    offset: int = Query(0, ge=0, description="从最新事件起跳过条数；仅影响历史回放"),
):
    try:
        queue = await AnalystService.subscribe(
            agent_id, session_id, limit=limit, offset=offset
        )
    except AgentServiceError as exc:
        return JSONResponse(
            status_code=200,
            content=ApiResponseSchema.error(
                code=exc.code,
                message=exc.message,
                data=exc.data,
            ).model_dump(),
        )

    async def event_stream():
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    payload = await asyncio.wait_for(queue.get(), timeout=15.0)
                except asyncio.TimeoutError:
                    yield ": keep-alive\n\n"
                    continue
                event = payload.get("event", "message")
                data_str = json.dumps(payload.get("data"), ensure_ascii=False, default=str)
                event_id = payload.get("id")
                if event_id is not None:
                    yield f"id: {event_id}\nevent: {event}\ndata: {data_str}\n\n"
                else:
                    yield f"event: {event}\ndata: {data_str}\n\n"
        finally:
            await AnalystService.unsubscribe(agent_id, session_id, queue)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/approve", response_model=ApiResponseSchema[Any], summary="提交行为批准")
async def approve_agent(data: ApproveRequestSchema, request: Request):
    try:
        await AnalystService.submit_approval(
            data.agent_id,
            data.session_id,
            data.approval_request_id,
            data.decisions,
            resolver_user_id=getattr(
                getattr(getattr(request.state, "auth_context", None), "user", None),
                "id",
                None,
            ),
        )
    except AgentServiceError as exc:
        return ApiResponseSchema.error(code=exc.code, message=exc.message, data=exc.data)
    return ApiResponseSchema.success(data=None, message="批准决策已提交")


@router.post(
    "/cancel",
    response_model=ApiResponseSchema[CancelAgentResponseSchema],
    summary="取消正在运行的分析引擎",
)
async def cancel_agent(data: CancelAgentRequestSchema):
    cancelled = await AnalystService.cancel_agent(
        data.agent_id, data.session_id, reason=data.reason
    )
    return ApiResponseSchema.success(
        data=CancelAgentResponseSchema(agent_id=data.agent_id, cancelled=cancelled),
        message="取消请求已发送" if cancelled else "该 Agent 当前没有正在运行的任务",
    )
