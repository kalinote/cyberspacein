from loguru import logger
import re
from fastapi import APIRouter, Depends, Query
from typing import Annotated, List, Optional

from app.db.elasticsearch import get_es
from app.schemas.overview import (
    OverviewTimeSeriesParamsSchema,
    OverviewTimeSeriesStatsSchema,
    OverviewTimeUnitEnum,
)
from app.schemas.platform import PlatformBaseInfoSchema, PlatformCreateRequestSchema, PlatformFilterItemSchema
from app.schemas.general import PageParamsSchema, PageResponseSchema
from app.schemas.response import ApiResponseSchema
from app.models.platform.platform import PlatformModel
from app.utils.id_lib import generate_id
from app.utils.async_fetch import async_download_file
from app.utils.file_security import validate_image_file, get_file_extension_from_mime, calculate_file_hash
from app.utils.cos import upload_bytes_with_public_url, file_exists
from app.service.overview import fetch_time_field_stats

logger = logger.bind(name=__name__)

router = APIRouter(
    prefix="/platform",
    tags=["平台管理"],
)


def _time_series_params(
    n: int = Query(7, ge=1, description="近 n 天、近 n 周或近 n 月，默认 7"),
    unit: OverviewTimeUnitEnum = Query(
        OverviewTimeUnitEnum.day, description="统计单位：day / week / month，默认 day"
    ),
) -> OverviewTimeSeriesParamsSchema:
    return OverviewTimeSeriesParamsSchema(n=n, unit=unit)

@router.post("", response_model=ApiResponseSchema[PlatformBaseInfoSchema], summary="创建平台")
async def create_platform(data: PlatformCreateRequestSchema):
    platform_id = generate_id(data.name + data.url)
    
    existing_platform = await PlatformModel.find_one({"_id": platform_id})
    if existing_platform:
        return ApiResponseSchema.error(code=240901, message=f"平台已存在，名称: {data.name} 或 URL: {data.url}")
    
    existing_by_name = await PlatformModel.find_one({"name": data.name})
    if existing_by_name:
        return ApiResponseSchema.error(code=240902, message=f"平台名称已存在: {data.name}")
    
    existing_by_url = await PlatformModel.find_one({"url": data.url})
    if existing_by_url:
        return ApiResponseSchema.error(code=240903, message=f"平台URL已存在: {data.url}")
    
    processed_logo = ""
    if (data.logo or "").strip():
        try:
            logger.info(f"开始下载logo: {data.logo}")
            headers = {
                "accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
                "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
                "priority": "u=2, i",
                "sec-ch-ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "image",
                "sec-fetch-mode": "no-cors",
                "sec-fetch-site": "same-origin",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
            }
            headers["referer"] = data.url
            
            logo_data = await async_download_file(data.logo, headers=headers)
            
            is_valid, message, mime_type = validate_image_file(logo_data, data.logo)
            if is_valid and mime_type:
                # logger.info(f"Logo安全检查通过: {message}")
                
                file_hash = calculate_file_hash(logo_data, algorithm='sha256')
                file_ext = get_file_extension_from_mime(mime_type)
                object_key = f"logo/{file_hash}{file_ext}"
                
                if await file_exists(object_key):
                    logger.info(f"Logo文件已存在于COS中，直接使用: {object_key}")
                    processed_logo = object_key
                else:
                    cos_url = await upload_bytes_with_public_url(
                        logo_data,
                        object_key,
                        content_type=mime_type
                    )
                    processed_logo = cos_url
                    logger.info(f"Logo上传成功: {cos_url}")
            else:
                logger.warning(f"Logo安全检查失败: {message}，将使用空logo")
        except Exception as e:
            logger.error(f"处理logo时发生错误: {e}，将使用空logo")
    
    platform_model = PlatformModel(
        id=platform_id,
        name=data.name,
        description=data.description,
        type=data.type,
        net_type=data.net_type,
        status=data.status,
        url=data.url,
        logo=processed_logo,
        tags=data.tags,
        category=data.category,
        sub_category=data.sub_category,
        confidence=data.confidence,
        spider_name=data.spider_name,
        sections=data.sections
    )
    
    await platform_model.insert()
    logger.info(f"成功创建平台: {platform_id} - {data.name}")
    
    return ApiResponseSchema.success(data=PlatformBaseInfoSchema.from_doc(platform_model))

@router.get("/list", response_model=PageResponseSchema[PlatformBaseInfoSchema], summary="获取平台列表")
async def get_platform_list(
    params: PageParamsSchema = Depends(),
    type: Optional[str] = Query(None, description="平台类型筛选"),
    status: Optional[str] = Query(None, description="平台状态筛选"),
    category: Optional[str] = Query(None, description="平台分类筛选"),
    search: Optional[str] = Query(None, description="搜索关键词，用于模糊搜索平台名称和描述")
):
    skip = (params.page - 1) * params.page_size
    
    query_filters = {}
    if type:
        query_filters["type"] = type
    if status:
        query_filters["status"] = status
    if category:
        query_filters["category"] = category
    
    if search:
        search_pattern = re.compile(re.escape(search), re.IGNORECASE)
        query_filters["$or"] = [
            {"name": {"$regex": search_pattern}},
            {"description": {"$regex": search_pattern}}
        ]
    
    if query_filters:
        query = PlatformModel.find(query_filters)
    else:
        query = PlatformModel.find_all()
    
    total = await query.count()
    platforms = await query.skip(skip).limit(params.page_size).to_list()
    
    results = [PlatformBaseInfoSchema.from_doc(p) for p in platforms]
    return PageResponseSchema.create(results, total, params.page, params.page_size)

@router.get("/detail/{platform_id}", response_model=ApiResponseSchema[PlatformBaseInfoSchema], summary="获取平台详情")
async def get_platform_detail(platform_id: str):
    platform = await PlatformModel.find_one({"_id": platform_id})
    if not platform:
        return ApiResponseSchema.error(code=240407, message=f"平台不存在，ID: {platform_id}")
    
    return ApiResponseSchema.success(data=PlatformBaseInfoSchema.from_doc(platform))


@router.get(
    "/{platform_id}/new-data-status",
    response_model=OverviewTimeSeriesStatsSchema,
    summary="数据更新统计",
)
async def get_platform_new_data_status(
    platform_id: str,
    params: Annotated[OverviewTimeSeriesParamsSchema, Depends(_time_series_params)],
):
    platform = await PlatformModel.find_one({"_id": platform_id})
    if not platform:
        return ApiResponseSchema.error(code=240407, message=f"平台不存在，ID: {platform_id}")
    es = get_es()
    if not es:
        return ApiResponseSchema.error(code=250001, message="数据库连接失败")
    try:
        return await fetch_time_field_stats(
            es,
            "last_edit_at",
            params.unit,
            params.n,
            platform_keyword=platform.name,
        )
    except Exception as e:
        logger.exception(f"数据更新统计失败: {e}")
        return ApiResponseSchema.error(code=250005, message=f"数据更新统计失败: {str(e)}")


@router.get("/filter/platforms", response_model=ApiResponseSchema[List[PlatformFilterItemSchema]], summary="平台过滤器列表")
async def get_platform_filter_list():
    platforms = await PlatformModel.find_all().to_list()
    results = [PlatformFilterItemSchema.from_doc(p) for p in platforms]
    return ApiResponseSchema.success(data=results)


@router.get("/filter/sub_category", response_model=ApiResponseSchema[List[str]], summary="子分类过滤器列表")
async def get_platform_sub_category_filter():
    values = await PlatformModel.distinct("sub_category")
    result = sorted({v for v in values if v})
    return ApiResponseSchema.success(data=result)